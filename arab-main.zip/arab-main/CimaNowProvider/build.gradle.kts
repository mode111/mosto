version = 1

cloudstream {
    authors = listOf( "ImZaw" )

	language = "ar"
	
    status = 1

    tvTypes = listOf( "TvSeries" , "Movie" )

    iconUrl = "https://www.google.com/s2/favicons?domain=cimanow.cc&sz=%size%"
}