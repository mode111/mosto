version = 7

cloudstream {
    authors = listOf( "ImZaw" )

	language = "ar"
	
    status = 1

    tvTypes = listOf( "TvSeries" , "Movie" , "Anime" )

    iconUrl = "https://www.google.com/s2/favicons?domain=mycima.tv&sz=%size%"
}
