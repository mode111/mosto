version = 2

cloudstream {
    authors = listOf( "ImZaw" )

	language = "ar"

    status = 1

    tvTypes = listOf( "Anime" , "AnimeMovie" , "OVA" )

    iconUrl = "https://www.google.com/s2/favicons?domain=animeblkom.net&sz=%size%"
}