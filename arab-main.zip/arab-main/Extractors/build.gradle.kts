version = 1

cloudstream {
    description = "This is required to be downloaded."
    authors = listOf( "ImZaw" )

	language = "ar"
	
    status = 1

    tvTypes = listOf( "TvSeries" , "Movie" , "Anime" , "AsianDrama" )
}